MFi Controller Lab 1.0.97 Build 205 R11
RuntimeRecovery205 is generated from the live iPad, but presence on disk is not repair authority.
- FORENSIC_INVENTORY.txt: discovery only; disabled/backups/history can never drive actions.
- FUNCTIONAL_AUTHORITY.tsv: current active/legitimate project components only.
- FUNCTIONAL_JUSTIFICATION.tsv: one concrete evidence reason for every functional external component.
- AUTHORITY_AUDIT.tsv: every captured external file marked FUNCTIONAL or FORENSIC_ONLY with the selection/exclusion reason.
- app manifest: ProyectoD + APP services/tweaks + shared project data required by app features.
- driver manifest: Driver 4.0 current runtime + shared integration required by the driver.
- full manifest: exact repair authority used only when REINSTALL COMPONENTS is explicitly pressed.
- services manifest: current legitimate launchd jobs; expected_loaded comes only from live launchctl state.
- repair reloads only unhealthy/changed services and resprings only when a MobileSubstrate file changed.
- retroarch.cfg and DRetroArchControllerBridge are verified/repaired; retroarch.cfg is preserved on uninstall.
RetroArch.app, ROMs and saves are never part of install/repair/uninstall.
