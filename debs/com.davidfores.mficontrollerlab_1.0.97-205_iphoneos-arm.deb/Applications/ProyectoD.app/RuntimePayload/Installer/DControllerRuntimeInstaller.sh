#!/bin/sh
set -eu

APP_ROOT="${APP_ROOT:-}"
PAYLOAD=""
MANIFEST=""
STATE_DIR="/var/mobile/Library/MainControllers"
REQUEST="$STATE_DIR/install-request.plist"
STATUS="$STATE_DIR/install-status.txt"
BACKUP_ROOT="/var/mobile/MFiControllerLabBackups"
ACTION="${1:-process-request}"
STAMP="$(date +%Y%m%d_%H%M%S 2>/dev/null || echo process_$$)"
BACKUP="$BACKUP_ROOT/Runtime_$STAMP"
STAGE="/var/mobile/.mficontrollerlab-stage-$$"

write_status()
{
    mkdir -p "$STATE_DIR"
    printf '%s\n' "$1" > "$STATUS"
    chown mobile:mobile "$STATUS" 2>/dev/null || true
    chmod 644 "$STATUS" 2>/dev/null || true
}

fail()
{
    write_status "ERROR:$1"
    echo "RESULTADO=FALLO"
    echo "ERROR=$1"
    exit 1
}

cleanup()
{
    rm -rf "$STAGE" 2>/dev/null || true
}
trap cleanup EXIT HUP INT TERM

set_app_root()
{
    candidate="$1"
    [ -n "$candidate" ] || fail "APP_ROOT_VACIO"
    case "$candidate" in
        /Applications/ProyectoD.app|/var/mobile/Containers/Bundle/Application/*/ProyectoD.app) ;;
        *) fail "APP_ROOT_NO_AUTORIZADO:$candidate" ;;
    esac
    [ -d "$candidate" ] || fail "APP_ROOT_AUSENTE:$candidate"
    [ -s "$candidate/RuntimePayload/runtime-manifest.tsv" ] ||
        fail "APP_SIN_MANIFIESTO_RUNTIME"
    APP_ROOT="$candidate"
    PAYLOAD="$APP_ROOT/RuntimePayload"
    MANIFEST="$PAYLOAD/runtime-manifest.tsv"
DRIVER_MANIFEST="$PAYLOAD/driver-manifest.tsv"
APP_COMPONENTS_MANIFEST="$PAYLOAD/app-components-manifest.tsv"
}

find_native_app_root()
{
    for candidate in /var/mobile/Containers/Bundle/Application/*/ProyectoD.app /Applications/ProyectoD.app; do
        [ -d "$candidate" ] || continue
        if [ -s "$candidate/Info.plist" ] &&
           grep -q 'com.davidfores.ProyectoD' "$candidate/Info.plist" 2>/dev/null; then
            printf '%s' "$candidate"
            return 0
        fi
    done
    return 1
}

sha256_file()
{
    openssl dgst -sha256 "$1" | sed 's/^.*= //'
}

# Payload binaries are copied byte-for-byte; they are not re-signed during repair.
manifest_ready()
{
    [ -s "$MANIFEST" ] || return 1
    ! grep -q 'PENDING\|required-blocked' "$MANIFEST" || return 1
    count=0
    while IFS="$(printf '\t')" read -r source_rel destination mode owner group expected policy; do
        case "$source_rel" in ""|\#*) continue ;; esac
        count=$((count + 1))
        [ -n "$destination" ] && [ -n "$mode" ] && [ -n "$expected" ] || return 1
        [ -f "$PAYLOAD/$source_rel" ] || return 1
        [ "$(sha256_file "$PAYLOAD/$source_rel")" = "$expected" ] || return 1
    done < "$MANIFEST"
    [ "$count" -gt 0 ]
}

retroarch_present()
{
    [ -d /Applications/RetroArch.app ]
}

should_process()
{
    policy="$1"
    case "$policy" in
        optional-retroarch|optional-retroarch-mutable)
            retroarch_present || return 1
            ;;
    esac
    return 0
}

verify_all()
{
    bad=0
    while IFS="$(printf '\t')" read -r source_rel destination mode owner group expected policy; do
        case "$source_rel" in ""|\#*) continue ;; esac
        should_process "$policy" || continue
        if [ ! -f "$destination" ]; then
            echo "MISSING=$destination"
            bad=1
            continue
        fi
        case "$policy" in
            mutable|*-mutable)
                echo "MUTABLE_OK=$destination"
                continue
                ;;
        esac

        actual="$(sha256_file "$destination")"
        if [ "$actual" != "$expected" ]; then
            echo "HASH_MISMATCH=$destination"
            bad=1
        fi
    done < "$MANIFEST"
    return "$bad"
}

backup_destinations()
{
    mkdir -p "$BACKUP"
    while IFS="$(printf '\t')" read -r source_rel destination mode owner group expected policy; do
        case "$source_rel" in ""|\#*) continue ;; esac
        should_process "$policy" || continue
        if [ -e "$destination" ]; then
            target="$BACKUP$destination"
            mkdir -p "$(dirname "$target")"
            cp -p "$destination" "$target"
        fi
    done < "$MANIFEST"
    cp -p "$MANIFEST" "$BACKUP/runtime-manifest.tsv"
}

stage_payload()
{
    rm -rf "$STAGE"
    mkdir -p "$STAGE"
    while IFS="$(printf '\t')" read -r source_rel destination mode owner group expected policy; do
        case "$source_rel" in ""|\#*) continue ;; esac
        should_process "$policy" || continue
        source="$PAYLOAD/$source_rel"
        [ -f "$source" ] || fail "PAYLOAD_AUSENTE:$source_rel"
        actual="$(sha256_file "$source")"
        [ "$actual" = "$expected" ] || fail "PAYLOAD_HASH_INVALIDO:$source_rel"
        staged="$STAGE$destination"
        mkdir -p "$(dirname "$staged")"
        cp -p "$source" "$staged"
        chmod "$mode" "$staged"
        chown "$owner:$group" "$staged" 2>/dev/null || true
    done < "$MANIFEST"
}

install_stage()
{
    while IFS="$(printf '\t')" read -r source_rel destination mode owner group expected policy; do
        case "$source_rel" in ""|\#*) continue ;; esac
        should_process "$policy" || continue
        staged="$STAGE$destination"

        # mutable = una sola copia viva: instalar si falta, conservar si existe.
        case "$policy" in
            mutable|*-mutable)
                if [ -e "$destination" ]; then
                    echo "MUTABLE_CONSERVADO=$destination"
                    continue
                fi
                ;;
        esac

        mkdir -p "$(dirname "$destination")"
        temporary="${destination}.mficontrollerlab-new-$$"
        cp -p "$staged" "$temporary"
        chmod "$mode" "$temporary"
        chown "$owner:$group" "$temporary" 2>/dev/null || true
        mv -f "$temporary" "$destination"
    done < "$MANIFEST"
}

restore_backup()
{
    [ -d "$BACKUP" ] || return 0
    find "$BACKUP" -type f ! -name runtime-manifest.tsv | while IFS= read -r file; do
        rel="${file#$BACKUP}"
        mkdir -p "$(dirname "$rel")"
        cp -p "$file" "$rel"
    done
}

load_services()
{
    for plist in \
        /Library/LaunchDaemons/com.codex.driver4.slotrelease.plist \
        /Library/LaunchDaemons/com.ghostframe.controllerprovider.mobilebluetooth.v144r2.plist \
        /Library/LaunchDaemons/com.ghostframe.driver4.retroadapter.r3.plist \
        /Library/LaunchDaemons/com.ghostframe.nimbusphysicalbus.v150r5.plist \
        /Library/LaunchDaemons/com.ghostframe.testerhybrid.xbox.v183.plist \
        /Library/LaunchDaemons/com.ghostframe.testerhybrid.nimbus.v183.plist \
        /Library/LaunchDaemons/com.davidfores.maincontrollers.batterytelemetry.plist
    do
        [ -f "$plist" ] || continue
        launchctl unload "$plist" >/dev/null 2>&1 || true
        launchctl load "$plist" >/dev/null 2>&1 || true
    done
}

unload_services()
{
    while IFS="$(printf '\t')" read -r source_rel destination mode owner group expected policy; do
        case "$destination" in
            /Library/LaunchDaemons/*.plist)
                [ -f "$destination" ] && launchctl unload "$destination" >/dev/null 2>&1 || true
                ;;
        esac
    done < "$MANIFEST"
}

repair()
{
    manifest_ready || fail "MANIFEST_NO_AUTORIZADO"
    write_status "RUNNING:VERIFY_REPAIR"
    stage_payload
    backup_destinations
    if ! install_stage; then
        restore_backup
        fail "COPIA_FALLO_ROLLBACK_REALIZADO"
    fi
    if ! verify_all; then
        restore_backup
        load_services
        fail "VERIFICACION_FALLO_ROLLBACK_REALIZADO"
    fi
    load_services
    write_status "OK:INSTALACION_REPARADA"
    echo "RESULTADO=OK"
    echo "ESTADO=INSTALACION_REPARADA"
    echo "BACKUP=$BACKUP"
    sync
    # APP support incluye ConnectionNotifier (MobileSubstrate/SpringBoard).
    # El respring activa cualquier notifier recién repuesto sin tocar la lógica
    # de los botones propios del Driver 4.0.
    killall -9 SpringBoard >/dev/null 2>&1 || true
}

uninstall_components()
{
    [ -s "$DRIVER_MANIFEST" ] || fail "DRIVER_MANIFEST_AUSENTE"
    write_status "RUNNING:UNINSTALL"
    backup_destinations
    unload_services
    while IFS="$(printf '\t')" read -r source_rel destination mode owner group expected policy; do
        case "$source_rel" in ""|\#*) continue ;; esac
        rm -f "$destination"
    done < "$DRIVER_MANIFEST"

    residual=0
    while IFS="$(printf '\t')" read -r source_rel destination mode owner group expected policy; do
        case "$source_rel" in ""|\#*) continue ;; esac
        if [ -e "$destination" ]; then
            echo "RESIDUO=$destination"
            residual=1
        fi
    done < "$DRIVER_MANIFEST"
    [ "$residual" -eq 0 ] || fail "QUEDAN_RESIDUOS"

    write_status "OK:COMPONENTES_DESINSTALADOS:YA_PUEDE_BORRAR_LA_APP"
    echo "RESULTADO=OK"
    echo "ESTADO=COMPONENTES_DESINSTALADOS"
    echo "BACKUP=$BACKUP"
}

is_driver_protected_destination()
{
    wanted="$1"
    [ -s "$DRIVER_MANIFEST" ] || return 1
    while IFS="$(printf '\t')" read -r source_rel destination mode owner group expected policy; do
        case "$source_rel" in ""|\#*) continue ;; esac
        [ "$destination" = "$wanted" ] && return 0
    done < "$DRIVER_MANIFEST"
    return 1
}

uninstall_application()
{
    write_status "RUNNING:UNINSTALL_APPLICATION"
    [ -s "$APP_COMPONENTS_MANIFEST" ] || fail "APP_COMPONENTS_MANIFEST_AUSENTE"
    app_backup="$BACKUP_ROOT/Application_$STAMP"
    mkdir -p "$app_backup"
    [ -d "$APP_ROOT" ] && cp -Rp "$APP_ROOT" "$app_backup/ProyectoD.app" 2>/dev/null || true

    # HÍBRIDA 3.0 + Installer + telemetría + ConnectionNotifier pertenecen a APP.
    while IFS="$(printf '\t')" read -r source_rel destination mode owner group expected policy; do
        case "$source_rel" in ""|\#*) continue ;; esac
        if [ -e "$destination" ]; then
            target="$app_backup$destination"
            mkdir -p "$(dirname "$target")"
            cp -p "$destination" "$target" 2>/dev/null || true
        fi
        case "$destination" in
            /Library/LaunchDaemons/*.plist)
                [ -f "$destination" ] && launchctl unload "$destination" >/dev/null 2>&1 || true
                ;;
        esac
    done < "$APP_COMPONENTS_MANIFEST"

    while IFS="$(printf '\t')" read -r source_rel destination mode owner group expected policy; do
        case "$source_rel" in ""|\#*) continue ;; esac
        [ -e "$destination" ] && rm -f "$destination" || true
    done < "$APP_COMPONENTS_MANIFEST"

    launchctl unload /Library/LaunchDaemons/com.davidfores.maincontrollers.batterytelemetry.plist >/dev/null 2>&1 || true
    killall ProyectoD >/dev/null 2>&1 || true

    # 1) Contenedor completo de datos de la app: perfiles, layouts, capturas,
    # imágenes, Exports, preferencias, caches, tmp y cualquier dato futuro.
    for container_root in /var/mobile/Containers/Data/Application /var/mobile/Applications; do
        [ -d "$container_root" ] || continue
        for container in "$container_root"/*; do
            [ -d "$container" ] || continue
            metadata="$container/.com.apple.mobile_container_manager.metadata.plist"
            if [ -f "$metadata" ] && grep -a -q 'com.davidfores.ProyectoD' "$metadata" 2>/dev/null; then
                cp -Rp "$container" "$app_backup/UserDataContainer" 2>/dev/null || true
                rm -rf "$container"
                echo "APP_USER_CONTAINER_BORRADO=$container"
            fi
        done
    done

    # 2) Datos externos creados por MFi Controller Lab.
    # Los tres mutables compartidos NO se borran aquí:
    # controller-remaps.bin, shortcut-overrides.bin y retroarch.cfg.
    for path in \
        "$STATE_DIR/trial-profile.plist" \
        "$STATE_DIR/capture-control.bin" \
        "$STATE_DIR/capture-request.plist" \
        "$STATE_DIR/controller-remaps.plist" \
        "$STATE_DIR/mac-upload-request.txt" \
        "$STATE_DIR/mac-upload-status.txt" \
        "$STATE_DIR/install-request.plist" \
        "$STATE_DIR/install-status.txt" \
        "$STATE_DIR/BatteryLearningV1.bin" \
        "$STATE_DIR/BatteryLearningV2.plist" \
        /var/mobile/DBatteryTelemetryService.log
    do
        [ -e "$path" ] && rm -f "$path" || true
    done

    # 3) Perfiles compartidos creados/importados por el usuario.
    # Conserva automáticamente cualquier fichero de Profiles protegido por
    # driver-manifest.tsv (actualmente 8bitdo-sfc30.dprofile).
    profiles_dir="$STATE_DIR/Profiles"
    if [ -d "$profiles_dir" ]; then
        for path in "$profiles_dir"/*; do
            [ -e "$path" ] || continue
            if is_driver_protected_destination "$path"; then
                echo "PERFIL_DRIVER_CONSERVADO=$path"
            else
                rm -rf "$path"
                echo "PERFIL_USUARIO_BORRADO=$path"
            fi
        done
    fi

    # 4) Estados temporales propios de APP / TEST / Notifier / Telemetry.
    # Se conservan buses/estados pertenecientes a Driver 4.0.
    for path in \
        /tmp/DControllerTesterBusV1.bin \
        /tmp/DControllerNotifierPresenceV1.bin \
        /tmp/DControllerBatteryState.bin \
        /tmp/DControllerTelemetryState.bin \
        /tmp/DControllerConnectionNotifier.log \
        /tmp/DControllerImportedProfilePurgeV1.bin \
        /tmp/DControllerImportedProfilePurgeV1.bin.tmp \
        /tmp/MFiControllerLab_R21_chain.log \
        /tmp/MFiControllerLab_R21_ui.log
    do
        [ -e "$path" ] && rm -f "$path" || true
    done

    # 5) Bundle. Driver 4.0 y RetroArch quedan intactos.
    [ -e "$APP_ROOT" ] && rm -rf "$APP_ROOT" || true
    [ ! -e "$APP_ROOT" ] || fail "APP_NO_ELIMINADA"

    # El icono se invalida antes del respring final.
    uicache >/dev/null 2>&1 || true
    sync

    echo "RESULTADO=OK"
    echo "ESTADO=APLICACION_DESINSTALADA"
    echo "DATOS_USUARIO_APP_BORRADOS=SI"
    echo "DRIVER4_CONSERVADO=SI"
    echo "CONTROLLER_REMAPS_BIN_CONSERVADO=SI"
    echo "SHORTCUT_OVERRIDES_BIN_CONSERVADO=SI"
    echo "RETROARCH_CFG_CONSERVADO=SI"
    echo "BACKUP=$app_backup"

    # El proceso sigue en memoria y puede retirar su helper/plist al final.
    rm -f /Library/LaunchDaemons/com.davidfores.mficontrollerlab.installer.plist
    rm -f /usr/libexec/DControllerRuntimeInstaller

    # Último paso obligatorio: descarga app/notifier de SpringBoard y hace
    # desaparecer el icono de MFi Controller Lab.
    killall -9 SpringBoard >/dev/null 2>&1 || true
}

read_request_value()
{
    key="$1"
    [ -s "$REQUEST" ] || fail "SOLICITUD_AUSENTE"
    value="$(plutil -key "$key" "$REQUEST" 2>/dev/null || true)"
    if [ -z "$value" ]; then
        value="$(grep -A1 "<key>$key</key>" "$REQUEST" | tail -n1 | sed -e 's/<[^>]*>//g' -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//')"
    fi
    printf '%s' "$value"
}

process_request()
{
    action="$(read_request_value action)"
    requested_root="$(read_request_value appRoot)"
    [ -n "$requested_root" ] || requested_root="$(find_native_app_root || true)"
    set_app_root "$requested_root"
    rm -f "$REQUEST"
    case "$action" in
        verify-repair|install-current|repair) repair ;;
        uninstall-components|uninstall-current) uninstall_components ;;
        uninstall-application) uninstall_application ;;
        *) fail "SOLICITUD_DESCONOCIDA:$action" ;;
    esac
}

if [ "$ACTION" != "process-request" ]; then
    [ -n "$APP_ROOT" ] || APP_ROOT="$(find_native_app_root || true)"
    set_app_root "$APP_ROOT"
fi

case "$ACTION" in
    verify)
        manifest_ready || fail "MANIFEST_NO_AUTORIZADO"
        if verify_all; then
            write_status "OK:INSTALACION_CORRECTA"
            echo "RESULTADO=OK"
            echo "ESTADO=INSTALACION_CORRECTA"
        else
            fail "COMPONENTES_AUSENTES_O_DANADOS"
        fi
        ;;
    repair|install-all) repair ;;
    uninstall|uninstall-components) uninstall_components ;;
    uninstall-application) uninstall_application ;;
    process-request) process_request ;;
    *) fail "ACCION_NO_VALIDA:$ACTION" ;;
esac
