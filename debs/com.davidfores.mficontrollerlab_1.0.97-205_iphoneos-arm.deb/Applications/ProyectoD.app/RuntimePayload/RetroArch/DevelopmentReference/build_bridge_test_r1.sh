#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/Sources"
BUILD="$ROOT/Build"
OUT="$BUILD/DRetroArchControllerBridge.dylib"
LOG="$BUILD/build.log"
XCODE="${XCODE_APP:-/Volumes/Xcode/Xcode.app}"
TOOLCHAIN="$XCODE/Contents/Developer/Toolchains/XcodeDefault.xctoolchain"
CLANG="$TOOLCHAIN/usr/bin/clang"
LIPO="$TOOLCHAIN/usr/bin/lipo"
SDK="$XCODE/Contents/Developer/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS9.3.sdk"

fail(){ echo "RESULTADO=FALLO"; echo "ERROR=$1"; exit 1; }
for f in DRetroArchControllerBridge.c DControllerLogicalMapper.c DControllerRemapRuntime.c DShortcutOverrideRuntime.c DControllerTransport.c; do
  test -s "$SRC/$f" || fail "FALTA_FUENTE_$f"
done

test -x "$CLANG" || fail "CLANG_XCODE_7_3_1_AUSENTE"
test -x "$LIPO" || fail "LIPO_XCODE_7_3_1_AUSENTE"
test -d "$SDK" || fail "SDK_IPHONEOS9_3_AUSENTE"

grep -Fq 'RETROARCH_AXIS_DIRECT_J1J2_NO_ZERO_FALLBACK_TEST_R1' "$SRC/DRetroArchControllerBridge.c" || fail "MARCADOR_TEST_AUSENTE"
if grep -Fq 'DControllerAxisSelectV185' "$SRC/DRetroArchControllerBridge.c"; then fail "FALLBACK_V185_SIGUE_EN_FUENTE"; fi
if grep -Fq 'DControllerAxisFallbackV185.h' "$SRC/DRetroArchControllerBridge.c"; then fail "INCLUDE_FALLBACK_SIGUE_EN_FUENTE"; fi

python3 - "$SRC/DRetroArchControllerBridge.c" <<'PY_VALIDATE_AXIS'
from pathlib import Path
import re
import sys

source = Path(sys.argv[1])
text = source.read_text()

required = {
    "R9_MARKER":
        text.count("DRetroArchAxisDiagnosticR9Marker"),

    "R9_DBRIDGEAXIS":
        len(
            re.findall(
                r"static\s+int16_t\s+DBridgeAxis\s*\(",
                text
            )
        ),

    "R9_DPLAYERAXIS_CALL":
        text.count(
            "result =\n"
            "        DPlayerAxis("
        ),

    "R9_DECODE_CALL":
        text.count(
            "decoded =\n"
            "        DDecodeJoyaxis("
        ),

    "R9_RETURN_RESULT":
        text.count("return result;"),

    "R9_LX_NEG":
        text.count('"R9_LX_NEG"'),

    "R9_LX_POS":
        text.count('"R9_LX_POS"'),

    "R9_LY_NEG":
        text.count('"R9_LY_NEG"'),

    "R9_LY_POS":
        text.count('"R9_LY_POS"'),

    "R9_RX_NEG":
        text.count('"R9_RX_NEG"'),

    "R9_RX_POS":
        text.count('"R9_RX_POS"'),

    "R9_RY_NEG":
        text.count('"R9_RY_NEG"'),

    "R9_RY_POS":
        text.count('"R9_RY_POS"'),
}

for name, count in required.items():
    print(f"{name}={count}")

bad = {
    name: count
    for name, count in required.items()
    if count < 1
}

if bad:
    print("RESULTADO=FALLO")
    print("ERROR=VALIDACION_R9")
    print("DETALLE=" + repr(bad))
    sys.exit(1)

print("VALIDACION_R9=CORRECTA")
PY_VALIDATE_AXIS
rm -rf "$BUILD"; mkdir -p "$BUILD"
unset DEVELOPER_DIR SDKROOT TOOLCHAINS XCODE_DEVELOPER_USR_PATH 2>/dev/null || true
export PATH="$TOOLCHAIN/usr/bin:/usr/bin:/bin:/usr/sbin:/sbin"
export COMPILER_PATH="$TOOLCHAIN/usr/bin"

if ! "$CLANG" -B"$TOOLCHAIN/usr/bin" -arch armv7 -isysroot "$SDK" \
  -miphoneos-version-min=9.0 -std=gnu99 -dynamiclib -O2 -Wall -Wextra \
  -Werror=implicit-function-declaration -Wno-unused-function -Wno-unused-variable \
  -I"$SRC" \
  "$SRC/DRetroArchControllerBridge.c" \
  "$SRC/DControllerLogicalMapper.c" \
  "$SRC/DControllerRemapRuntime.c" \
  "$SRC/DShortcutOverrideRuntime.c" \
  "$SRC/DControllerTransport.c" \
  -Wl,-undefined,error -o "$OUT" >"$LOG" 2>&1; then
  cat "$LOG"; fail "COMPILACION_ARMV7_FALLO"
fi
if grep -Fq ' warning:' "$LOG"; then cat "$LOG"; fail "COMPILACION_CON_WARNINGS"; fi
"$LIPO" -info "$OUT" | grep -Eq 'armv7|arm_v7' || fail "BINARIO_NO_ARMV7"
/usr/bin/file "$OUT" | grep -Eq 'Mach-O.*arm_v7|Mach-O.*armv7' || fail "BINARIO_NO_MACHO_ARMV7"
STR="$BUILD/strings.txt"; /usr/bin/strings "$OUT" > "$STR"
for marker in \
 'DRIVER4_R3R1_JOYAXIS_RETROARCH_1_9_14_R2' \
 'CODEX_DRIVER4_GLOBAL_SHORTCUTS_J1_J2_R1' \
 '/tmp/DControllerJ1StateFile.bin' \
 '/tmp/DControllerJ2StateFile.bin' \
 '/var/mobile/Library/MainControllers/controller-remaps.bin' \
 'BUILD185_REMAP_NORMALIZE_LEGACY_ONE_WAY_TO_SWAP_R1' \
 'RETROARCH_AXIS_DIRECT_J1J2_NO_ZERO_FALLBACK_TEST_R1'; do
  grep -Fq "$marker" "$STR" || fail "BINARIO_SIN_MARCADOR:$marker"
done
if grep -Fq 'BUILD185_AXIS_FALLBACK_TO_ORIGINAL_WHEN_BRIDGE_ZERO_R1' "$STR"; then fail "BINARIO_CON_FALLBACK_V185"; fi
chmod 755 "$OUT"
SHA="$(shasum -a 256 "$OUT")"; SHA="${SHA%% *}"
printf '%s  %s\n' "$SHA" "$(basename "$OUT")" > "$OUT.sha256"
echo "RESULTADO=CORRECTO"
echo "BRIDGE_ARMV7=SI"
echo "WARNINGS=0"
echo "FALLBACK_V185=ELIMINADO"
echo "AXIS_J1_J2=RETORNO_DIRECTO"
echo "BRIDGE=$OUT"
echo "SHA256=$SHA"
