#!/bin/bash
set -euo pipefail

ROOT_PREFIX="${MFI_HYBRID_ROOT:-}"
INCOMING="${MFI_HYBRID_INCOMING:-${ROOT_PREFIX}/var/mobile/MFiHybrid183Incoming}"
APP="${ROOT_PREFIX}/Applications/ProyectoD.app"
APP_NEW="${ROOT_PREFIX}/Applications/ProyectoD.app.HIBRIDA183.new"
APP_OLD="${ROOT_PREFIX}/Applications/ProyectoD.app.HIBRIDA183.old"
BACKUP_ROOT="${ROOT_PREFIX}/var/mobile/MFiControllerLabBackups"

XBOX_BIN="${ROOT_PREFIX}/usr/local/libexec/DControllerTesterXboxPublisherV183"
NIMBUS_BIN="${ROOT_PREFIX}/usr/local/libexec/DControllerTesterNimbusPublisherV183"
XBOX_PLIST="${ROOT_PREFIX}/Library/LaunchDaemons/com.ghostframe.testerhybrid.xbox.v183.plist"
NIMBUS_PLIST="${ROOT_PREFIX}/Library/LaunchDaemons/com.ghostframe.testerhybrid.nimbus.v183.plist"
BITDO_DYLIB="${ROOT_PREFIX}/Library/MobileSubstrate/DynamicLibraries/DControllerTester8BitDoObserverV183.dylib"
BITDO_PLIST="${ROOT_PREFIX}/Library/MobileSubstrate/DynamicLibraries/DControllerTester8BitDoObserverV183.plist"
TESTER_BUS="${ROOT_PREFIX}/tmp/DControllerTesterBusV1.bin"

SOURCE_APP="$INCOMING/ProyectoD.app"
SOURCE_PAYLOAD="$INCOMING/HybridPayload"

BACKUP=""
BACKUP_READY=0
APP_SWAPPED=0
INSTALL_COMPLETE=0

require_command()
{
    command -v "$1" >/dev/null 2>&1 || {
        echo "ERROR=FALTA_COMANDO_REMOTO_$1"
        exit 10
    }
}

for command_name in cp mv rm mkdir chmod chown date sync launchctl killall ldid
do
    require_command "$command_name"
done

for required in \
    "$SOURCE_APP/ProyectoD" \
    "$SOURCE_APP/Info.plist" \
    "$SOURCE_PAYLOAD/usr/local/libexec/DControllerTesterXboxPublisherV183" \
    "$SOURCE_PAYLOAD/usr/local/libexec/DControllerTesterNimbusPublisherV183" \
    "$SOURCE_PAYLOAD/Library/LaunchDaemons/com.ghostframe.testerhybrid.xbox.v183.plist" \
    "$SOURCE_PAYLOAD/Library/LaunchDaemons/com.ghostframe.testerhybrid.nimbus.v183.plist" \
    "$SOURCE_PAYLOAD/Library/MobileSubstrate/DynamicLibraries/DControllerTester8BitDoObserverV183.dylib" \
    "$SOURCE_PAYLOAD/Library/MobileSubstrate/DynamicLibraries/DControllerTester8BitDoObserverV183.plist"
do
    test -e "$required" || {
        echo "ERROR=PAYLOAD_INCOMPLETO"
        echo "$required"
        exit 11
    }
done

test -d "${ROOT_PREFIX}/Applications" || {
    echo "ERROR=NO_EXISTE_DIRECTORIO_APPLICATIONS"
    exit 12
}
test -d "${ROOT_PREFIX}/Library/LaunchDaemons" || {
    echo "ERROR=NO_EXISTE_LAUNCHDAEMONS"
    exit 13
}
test -d "${ROOT_PREFIX}/Library/MobileSubstrate/DynamicLibraries" || {
    echo "ERROR=NO_EXISTE_MOBILESUBSTRATE"
    exit 14
}
mkdir -p "${ROOT_PREFIX}/usr/local/libexec" "$BACKUP_ROOT"

rollback()
{
    status=$?
    trap - ERR INT TERM
    if [ "$INSTALL_COMPLETE" -eq 1 ]; then
        exit "$status"
    fi

    echo "ROLLBACK_BUILD183_HIBRIDA=INICIADO"
    launchctl unload "$XBOX_PLIST" >/dev/null 2>&1 || true
    launchctl unload "$NIMBUS_PLIST" >/dev/null 2>&1 || true

    rm -f "$XBOX_BIN" "$NIMBUS_BIN" "$XBOX_PLIST" "$NIMBUS_PLIST" \
        "$BITDO_DYLIB" "$BITDO_PLIST" "$TESTER_BUS" \
        "$XBOX_BIN.new" "$NIMBUS_BIN.new" \
        "$XBOX_PLIST.new" "$NIMBUS_PLIST.new" \
        "$BITDO_DYLIB.new" "$BITDO_PLIST.new"

    if [ "$BACKUP_READY" -eq 1 ]; then
        test ! -f "$BACKUP/HybridPrevious/DControllerTesterXboxPublisherV183" || \
            cp -p "$BACKUP/HybridPrevious/DControllerTesterXboxPublisherV183" "$XBOX_BIN"
        test ! -f "$BACKUP/HybridPrevious/DControllerTesterNimbusPublisherV183" || \
            cp -p "$BACKUP/HybridPrevious/DControllerTesterNimbusPublisherV183" "$NIMBUS_BIN"
        test ! -f "$BACKUP/HybridPrevious/com.ghostframe.testerhybrid.xbox.v183.plist" || \
            cp -p "$BACKUP/HybridPrevious/com.ghostframe.testerhybrid.xbox.v183.plist" "$XBOX_PLIST"
        test ! -f "$BACKUP/HybridPrevious/com.ghostframe.testerhybrid.nimbus.v183.plist" || \
            cp -p "$BACKUP/HybridPrevious/com.ghostframe.testerhybrid.nimbus.v183.plist" "$NIMBUS_PLIST"
        test ! -f "$BACKUP/HybridPrevious/DControllerTester8BitDoObserverV183.dylib" || \
            cp -p "$BACKUP/HybridPrevious/DControllerTester8BitDoObserverV183.dylib" "$BITDO_DYLIB"
        test ! -f "$BACKUP/HybridPrevious/DControllerTester8BitDoObserverV183.plist" || \
            cp -p "$BACKUP/HybridPrevious/DControllerTester8BitDoObserverV183.plist" "$BITDO_PLIST"
    fi

    rm -rf "$APP_NEW"
    if [ "$APP_SWAPPED" -eq 1 ]; then
        rm -rf "$APP"
        if [ -d "$APP_OLD" ]; then
            mv "$APP_OLD" "$APP"
        elif [ "$BACKUP_READY" -eq 1 ] && [ -d "$BACKUP/ProyectoD.app" ]; then
            cp -Rp "$BACKUP/ProyectoD.app" "$APP"
        fi
    fi

    test ! -f "$XBOX_PLIST" || launchctl load "$XBOX_PLIST" >/dev/null 2>&1 || true
    test ! -f "$NIMBUS_PLIST" || launchctl load "$NIMBUS_PLIST" >/dev/null 2>&1 || true
    sync || true
    echo "ROLLBACK_BUILD183_HIBRIDA=TERMINADO"
    echo "RESULTADO=ERROR_RESTAURADO"
    exit "$status"
}
trap rollback ERR INT TERM

STAMP="$(date +%Y%m%d_%H%M%S)"
test -n "$STAMP" || STAMP="proceso_$$"
BACKUP="$BACKUP_ROOT/Antes_BUILD183_HIBRIDA_R1_$STAMP"
mkdir -p "$BACKUP/HybridPrevious"

if [ -d "$APP" ]; then
    cp -Rp "$APP" "$BACKUP/ProyectoD.app"
fi
for existing in "$XBOX_BIN" "$NIMBUS_BIN" "$XBOX_PLIST" "$NIMBUS_PLIST" "$BITDO_DYLIB" "$BITDO_PLIST"
do
    if [ -f "$existing" ]; then
        cp -p "$existing" "$BACKUP/HybridPrevious/"
    fi
done
BACKUP_READY=1

echo "PREFLIGHT_REMOTO=CORRECTO"
echo "BACKUP_CREADO=$BACKUP"
echo "ALCANCE=APP_Y_SEIS_ARCHIVOS_HIBRIDA"
echo "DRIVER4_MODIFICADO=NO"
echo "J1_J2_MODIFICADOS=NO"
echo "RETROARCH_MODIFICADO=NO"

launchctl unload "$XBOX_PLIST" >/dev/null 2>&1 || true
launchctl unload "$NIMBUS_PLIST" >/dev/null 2>&1 || true

rm -rf "$APP_NEW" "$APP_OLD"
cp -Rp "$SOURCE_APP" "$APP_NEW"
chmod 755 "$APP_NEW/ProyectoD"
ldid -S "$APP_NEW/ProyectoD"

cp -p "$SOURCE_PAYLOAD/usr/local/libexec/DControllerTesterXboxPublisherV183" "$XBOX_BIN.new"
cp -p "$SOURCE_PAYLOAD/usr/local/libexec/DControllerTesterNimbusPublisherV183" "$NIMBUS_BIN.new"
cp -p "$SOURCE_PAYLOAD/Library/LaunchDaemons/com.ghostframe.testerhybrid.xbox.v183.plist" "$XBOX_PLIST.new"
cp -p "$SOURCE_PAYLOAD/Library/LaunchDaemons/com.ghostframe.testerhybrid.nimbus.v183.plist" "$NIMBUS_PLIST.new"
cp -p "$SOURCE_PAYLOAD/Library/MobileSubstrate/DynamicLibraries/DControllerTester8BitDoObserverV183.dylib" "$BITDO_DYLIB.new"
cp -p "$SOURCE_PAYLOAD/Library/MobileSubstrate/DynamicLibraries/DControllerTester8BitDoObserverV183.plist" "$BITDO_PLIST.new"

chmod 755 "$XBOX_BIN.new" "$NIMBUS_BIN.new" "$BITDO_DYLIB.new"
chmod 644 "$XBOX_PLIST.new" "$NIMBUS_PLIST.new" "$BITDO_PLIST.new"
ldid -S "$XBOX_BIN.new"
ldid -S "$NIMBUS_BIN.new"
ldid -S "$BITDO_DYLIB.new"

mv "$XBOX_BIN.new" "$XBOX_BIN"
mv "$NIMBUS_BIN.new" "$NIMBUS_BIN"
mv "$XBOX_PLIST.new" "$XBOX_PLIST"
mv "$NIMBUS_PLIST.new" "$NIMBUS_PLIST"
mv "$BITDO_DYLIB.new" "$BITDO_DYLIB"
mv "$BITDO_PLIST.new" "$BITDO_PLIST"

chown root:wheel "$XBOX_BIN" "$NIMBUS_BIN" "$XBOX_PLIST" "$NIMBUS_PLIST" \
    "$BITDO_DYLIB" "$BITDO_PLIST"

if [ -d "$APP" ]; then
    mv "$APP" "$APP_OLD"
    APP_SWAPPED=1
fi
mv "$APP_NEW" "$APP"
APP_SWAPPED=1
chown -R root:wheel "$APP"

rm -f "$TESTER_BUS"
launchctl load "$XBOX_PLIST"
launchctl load "$NIMBUS_PLIST"

for installed in "$APP/ProyectoD" "$XBOX_BIN" "$NIMBUS_BIN" \
    "$XBOX_PLIST" "$NIMBUS_PLIST" "$BITDO_DYLIB" "$BITDO_PLIST"
do
    test -s "$installed" || {
        echo "ERROR=ARCHIVO_INSTALADO_INVALIDO"
        echo "$installed"
        false
    }
done

rm -rf "$APP_OLD"
if command -v uicache >/dev/null 2>&1; then
    uicache >/dev/null 2>&1 || true
fi
sync

INSTALL_COMPLETE=1
trap - ERR INT TERM

echo "INSTALACION_REMOTA=CORRECTA"
echo "VERSION=1.0.75"
echo "BUILD=183"
echo "RAMA=HIBRIDA_R1"
echo "APP_REEMPLAZADA=SI"
echo "RUNTIME_HIBRIDO_INSTALADO=SI"
echo "DRIVER4_ESCRITO=NO"
echo "RETROARCH_ESCRITO=NO"
echo "J1_J2_ESCRITOS=NO"
echo "BTSERVER_REINICIO_PENDIENTE=SI"
echo "BACKUP_REMOTO=$BACKUP"
echo "RESULTADO=CORRECTO"

(
    sleep 1
    killall -9 BTServer >/dev/null 2>&1 || true
    sleep 1
    killall -9 SpringBoard >/dev/null 2>&1 || true
) >/dev/null 2>&1 &

exit 0
