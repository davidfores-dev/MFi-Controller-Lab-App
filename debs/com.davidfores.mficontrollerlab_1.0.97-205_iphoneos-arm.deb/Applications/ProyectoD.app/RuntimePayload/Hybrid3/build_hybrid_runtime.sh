#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
RUNTIME="$ROOT/HybridRuntime"
SRC="$ROOT/Source"
RUNTIME_SRC="$RUNTIME/Sources"
PLISTS="$RUNTIME/Plists"
BUILD="$RUNTIME/Build"
PAYLOAD="$BUILD/Payload"

XCODE="/Volumes/Xcode/Xcode.app"
CLANG="$XCODE/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/bin/clang"
SDK="$XCODE/Contents/Developer/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS9.3.sdk"

for required in "$CLANG" "$SRC/DControllerSharedState.h" \
    "$SRC/DControllerTesterBusV1.h" \
    "$RUNTIME_SRC/DControllerTesterXboxPublisherV183.c" \
    "$RUNTIME_SRC/DControllerTesterNimbusPublisherV183.c" \
    "$RUNTIME_SRC/DControllerTester8BitDoObserverV183.c" \
    "$RUNTIME_SRC/DControllerTester8BitDoParserV183.h"
do
    test -e "$required" || {
        echo "ERROR=FALTA_ARCHIVO_RUNTIME"
        echo "$required"
        exit 1
    }
done

test -x "$CLANG" || {
    echo "ERROR=CLANG_XCODE_7_3_1_NO_DISPONIBLE"
    exit 2
}
test -d "$SDK" || {
    echo "ERROR=SDK_IPHONEOS9_3_NO_DISPONIBLE"
    exit 3
}

rm -rf "$BUILD"
mkdir -p \
    "$PAYLOAD/usr/local/libexec" \
    "$PAYLOAD/Library/LaunchDaemons" \
    "$PAYLOAD/Library/MobileSubstrate/DynamicLibraries"

COMMON=(
    -B"$XCODE/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/bin"
    -arch armv7
    -isysroot "$SDK"
    -miphoneos-version-min=9.0
    -O2
    -Wall
    -Wextra
    -Werror
    -Wno-deprecated-declarations
    -I"$SRC"
    -I"$RUNTIME_SRC"
)

unset DEVELOPER_DIR SDKROOT TOOLCHAINS XCODE_DEVELOPER_USR_PATH 2>/dev/null || true
export PATH="$XCODE/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/bin:/usr/bin:/bin:/usr/sbin:/sbin"
export COMPILER_PATH="$XCODE/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/bin"

"$CLANG" "${COMMON[@]}" \
    "$RUNTIME_SRC/DControllerTesterXboxPublisherV183.c" \
    -o "$PAYLOAD/usr/local/libexec/DControllerTesterXboxPublisherV183"

"$CLANG" "${COMMON[@]}" \
    "$RUNTIME_SRC/DControllerTesterNimbusPublisherV183.c" \
    -o "$PAYLOAD/usr/local/libexec/DControllerTesterNimbusPublisherV183"

"$CLANG" "${COMMON[@]}" \
    -dynamiclib \
    "$RUNTIME_SRC/DControllerTester8BitDoObserverV183.c" \
    -framework CoreFoundation \
    -ldl -lpthread \
    -install_name "/Library/MobileSubstrate/DynamicLibraries/DControllerTester8BitDoObserverV183.dylib" \
    -o "$PAYLOAD/Library/MobileSubstrate/DynamicLibraries/DControllerTester8BitDoObserverV183.dylib"

cp -p "$PLISTS/com.ghostframe.testerhybrid.xbox.v183.plist" \
    "$PAYLOAD/Library/LaunchDaemons/"
cp -p "$PLISTS/com.ghostframe.testerhybrid.nimbus.v183.plist" \
    "$PAYLOAD/Library/LaunchDaemons/"
cp -p "$PLISTS/DControllerTester8BitDoObserverV183.plist" \
    "$PAYLOAD/Library/MobileSubstrate/DynamicLibraries/"

chmod 755 "$PAYLOAD/usr/local/libexec/DControllerTesterXboxPublisherV183"
chmod 755 "$PAYLOAD/usr/local/libexec/DControllerTesterNimbusPublisherV183"
chmod 755 "$PAYLOAD/Library/MobileSubstrate/DynamicLibraries/DControllerTester8BitDoObserverV183.dylib"
chmod 644 "$PAYLOAD/Library/LaunchDaemons"/*.plist
chmod 644 "$PAYLOAD/Library/MobileSubstrate/DynamicLibraries/DControllerTester8BitDoObserverV183.plist"

printf '%s\n' \
    "BUILD_HYBRID_RUNTIME=CORRECTO" \
    "DRIVER4_COMPILADO=NO" \
    "DRIVER4_MODIFICADO=NO" \
    "J1_J2_ESCRITOS=NO" \
    "BUS_TESTER=/tmp/DControllerTesterBusV1.bin" \
    "PAYLOAD=$PAYLOAD"
